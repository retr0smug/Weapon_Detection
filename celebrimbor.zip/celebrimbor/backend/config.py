config = {
    "web_page_title": "Weapon Detection",
    "fps": 2,
    "yolo_path": "/home/arix/Documents/trying/YOLO_UI/weights",
    "object_classes": ["Gun", "Knife"],
}
